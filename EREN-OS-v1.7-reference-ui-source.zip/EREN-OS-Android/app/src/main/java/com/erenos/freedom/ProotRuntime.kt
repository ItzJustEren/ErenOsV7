package com.erenos.freedom

import android.content.Context
import android.os.Build
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/** Debian userspace through PRoot and one persistent PTY shell. This never grants Android root. */
class ProotRuntime(private val context: Context) {
    private val base = File(context.filesDir, "linux")
    private val rootfs = File(base, "debian-rootfs")
    private val proot = File(context.applicationInfo.nativeLibraryDir, "libproot.so")
    private val shared = File(context.getExternalFilesDir(null) ?: context.filesDir, "eren-shared")
    @Volatile private var session: IntArray? = null
    @Volatile private var initialized = false
    private val lock = Any()

    @Synchronized private fun initialize() {
        if (initialized && File(rootfs, "bin/sh").exists()) return
        check(proot.exists()) { "PRoot is missing. Run the GitHub Actions build." }
        base.mkdirs(); rootfs.mkdirs(); shared.mkdirs()
        // Android 10+ may block executing helper binaries extracted into app data.
        // The workflow packages loaders under jniLibs so Android extracts them into nativeLibraryDir.
        check(File(context.applicationInfo.nativeLibraryDir, "libproot-loader.so").exists()) {
            "PRoot loader is missing. Rebuild the APK with the updated GitHub Actions workflow."
        }
        if (!File(rootfs, "bin/sh").exists()) {
            val archive = context.assets.open("linux/debian-rootfs.tar.xz")
            extractXzTar(archive, rootfs)
        }
        // Debian rootfs archives may contain resolv.conf as a symlink to a systemd
        // runtime path that does not exist inside this minimal container. Replace it
        // with a regular file before starting PRoot so DNS always has a usable config.
        val resolv = File(rootfs, "etc/resolv.conf")
        resolv.parentFile?.mkdirs()
        try { java.nio.file.Files.deleteIfExists(resolv.toPath()) } catch (_: Exception) { }
        resolv.writeText("nameserver 1.1.1.1\nnameserver 8.8.8.8\noptions timeout:2 attempts:2\n")
        resolv.setReadable(true, false)
        File(rootfs, "etc/apt/apt.conf.d/99erenos-noninteractive").apply { parentFile?.mkdirs(); writeText("Dpkg::Use-Pty \"0\";\nAcquire::Retries \"3\";\n") }
        val sources = File(rootfs, "etc/apt/sources.list")
        if (!sources.exists() || sources.readText().isBlank()) sources.writeText("deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware\ndeb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware\ndeb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware\n")
        initialized = true
    }

    fun status(): String = "Debian + PRoot + persistent PTY; ABI=${Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"}; shared folder=${shared.absolutePath}"

    private fun ensureSession() = synchronized(lock) {
        initialize()
        if (session == null) {
            val started = NativePty.start(proot.absolutePath, rootfs.absolutePath, "/root", shared.absolutePath)
                ?: error("Could not create PTY session")
            check(started.size >= 2 && started[0] >= 0) { "Invalid PTY session" }
            session = started
            // Configure the interactive shell and discard its startup banner/prompt.
            NativePty.writeFd(started[0], "unset LD_PRELOAD; export PS1='\\[\\e[1;35m\\]root@eren:\\w# \\[\\e[0m\\]'; export DEBIAN_FRONTEND=noninteractive; export TERM=xterm-256color; cd /root\n".toByteArray())
        }
        session!!
    }

    @Volatile private var outputSink: ((String) -> Unit)? = null
    @Volatile private var readerThread: Thread? = null

    /** Start or attach to the same persistent PTY shell. Output is streamed until close(). */
    fun startTerminal(onOutput: (String) -> Unit) {
        outputSink = onOutput
        val current = ensureSession()
        synchronized(lock) {
            if (readerThread?.isAlive == true) return
            readerThread = Thread({
                while (session === current) {
                    try {
                        val bytes = NativePty.readFd(current[0], 8192) ?: break
                        if (bytes.isNotEmpty()) outputSink?.invoke(String(bytes, Charsets.UTF_8))
                    } catch (_: Exception) {
                        break
                    }
                }
            }, "eren-pty-reader").apply { isDaemon = true; start() }
        }
    }

    /** Send raw terminal bytes; supports Enter, Ctrl-C, arrows and interactive programs. */
    fun writeTerminal(data: String) {
        val current = ensureSession()
        val bytes = data.toByteArray(Charsets.UTF_8)
        var offset = 0
        while (offset < bytes.size) {
            val n = NativePty.writeFd(current[0], bytes.copyOfRange(offset, bytes.size))
            check(n > 0) { "PTY write failed" }
            offset += n
        }
    }

    fun resizeTerminal(rows: Int, cols: Int) {
        session?.let { NativePty.resizeFd(it[0], rows.coerceIn(2, 200), cols.coerceIn(10, 400)) }
    }

    /** Kept for older callers; interactive UI should use startTerminal/writeTerminal instead. */
    fun run(raw: String): String {
        val command = raw.trimEnd()
        if (command.isBlank()) return ""
        if (command == "clear") return "\u0000CLEAR"
        if (command == "help") return "Debian Linux via PRoot + PTY. Try: apt update, apt install python3, python3, pwd, cd /tmp. Shared files: /mnt/shared. Root is simulated; Android is not rooted."
        return "This runtime uses a live PTY. Open the terminal UI and enter commands there."
    }

    private fun extractXzTar(input: java.io.InputStream, destination: File) {
        XZCompressorInputStream(BufferedInputStream(input)).use { xz -> TarArchiveInputStream(xz).use { tar ->
            var entry = tar.nextTarEntry
            while (entry != null) {
                val target = File(destination, entry.name).canonicalFile
                require(target.path == destination.canonicalPath || target.path.startsWith(destination.canonicalPath + File.separator)) { "Unsafe path in rootfs archive" }
                when {
                    entry.isDirectory -> target.mkdirs()
                    entry.isSymbolicLink -> { target.parentFile?.mkdirs(); try { java.nio.file.Files.createSymbolicLink(target.toPath(), File(entry.linkName).toPath()) } catch (_: Exception) { } }
                    entry.isLink -> { target.parentFile?.mkdirs(); val link = File(destination, entry.linkName).canonicalFile; try { java.nio.file.Files.createLink(target.toPath(), link.toPath()) } catch (_: Exception) { if (link.isFile) link.copyTo(target, true) } }
                    entry.isFile -> {
                        target.parentFile?.mkdirs()
                        FileOutputStream(target).use { out ->
                            var remaining = entry.size
                            val buffer = ByteArray(32768)
                            while (remaining > 0) {
                                val count = tar.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                                if (count < 0) throw IllegalStateException("Truncated Debian rootfs archive")
                                out.write(buffer, 0, count); remaining -= count
                            }
                        }
                        target.setExecutable((entry.mode and 73) != 0, false); target.setReadable(true, false); target.setWritable(true, false)
                    }
                }
                entry = tar.nextTarEntry
            }
        } }
    }

    fun close() = synchronized(lock) { val old = session; session = null; outputSink = null; readerThread = null; old?.let { NativePty.closeFd(it[0], it[1]) } }
}
