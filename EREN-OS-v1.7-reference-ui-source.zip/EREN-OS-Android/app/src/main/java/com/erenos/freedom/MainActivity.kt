package com.erenos.freedom

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequest = 7401
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var linux: ProotRuntime

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        applyImmersiveMode()
        window.statusBarColor = Color.rgb(8, 6, 17)
        window.navigationBarColor = Color.rgb(8, 6, 17)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        linux = ProotRuntime(this)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 6, 17))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: WebChromeClient.FileChooserParams?
                ): Boolean {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = filePathCallback
                    val accept = fileChooserParams?.acceptTypes
                        ?.map { it.trim() }
                        ?.firstOrNull { it.isNotEmpty() && it != "*/*" }
                    val mime = when {
                        accept == null -> "*/*"
                        accept.startsWith(".") -> "*/*"
                        else -> accept
                    }
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = mime
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams?.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    return try {
                        this@MainActivity.startActivityForResult(Intent.createChooser(intent, if (mime.startsWith("audio/")) "Choose audio" else "Choose files"), fileChooserRequest)
                        true
                    } catch (_: Exception) {
                        this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                        this@MainActivity.fileChooserCallback = null
                        Toast.makeText(this@MainActivity, "No file picker available", Toast.LENGTH_SHORT).show()
                        false
                    }
                }
            }
            addJavascriptInterface(ErenBridge(), "ErenNative")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/eren-os/index.html")
    }

    @Deprecated("Deprecated in Android API; required for WebView file chooser callback compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != fileChooserRequest) return
        val callback = fileChooserCallback ?: return
        fileChooserCallback = null
        val uris = if (resultCode != RESULT_OK) null else {
            val clip = data?.clipData
            when {
                clip != null -> Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
        }
        callback.onReceiveValue(uris)
    }

    private fun applyImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    inner class ErenBridge {
        @JavascriptInterface fun runCommand(command: String, requestId: String) {
            // Compatibility bridge for older UI builds. The live terminal uses writeTerminal().
            worker.execute {
                val result = try { linux.run(command) } catch (e: Exception) { "ERROR: ${e.message ?: e.javaClass.simpleName}" }
                runOnUiThread {
                    val js = "window.erenNativeCommandResult(${JSONObject.quote(requestId)},${JSONObject.quote(result)})"
                    web.evaluateJavascript(js, null)
                }
            }
        }
        @JavascriptInterface fun startTerminal() {
            worker.execute {
                try {
                    linux.startTerminal { chunk ->
                        runOnUiThread {
                            if (::web.isInitialized) web.evaluateJavascript("window.erenNativeTerminalOutput(${JSONObject.quote(chunk)})", null)
                        }
                    }
                } catch (e: Exception) {
                    val message = "\u001b[31mEREN Linux startup failed: ${e.message ?: e.javaClass.simpleName}\r\n\u001b[0m"
                    runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.erenNativeTerminalOutput(${JSONObject.quote(message)})", null) }
                }
            }
        }
        @JavascriptInterface fun writeTerminal(data: String) {
            worker.execute { try { linux.writeTerminal(data) } catch (e: Exception) {
                val message = "\r\n\u001b[31mPTY write error: ${e.message ?: e.javaClass.simpleName}\r\n\u001b[0m"
                runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.erenNativeTerminalOutput(${JSONObject.quote(message)})", null) }
            } }
        }
        @JavascriptInterface fun resizeTerminal(rows: Int, cols: Int) {
            worker.execute { linux.resizeTerminal(rows, cols) }
        }
        @JavascriptInterface fun openBrowser(url: String) {
            runOnUiThread {
                startActivity(Intent(this@MainActivity, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_URL, safeUrl(url)))
            }
        }
        @JavascriptInterface fun runtimeStatus(): String = linux.status()
    }

    private fun safeUrl(raw: String): String {
        val value = raw.trim()
        if (value.startsWith("https://") || value.startsWith("http://")) return value
        return "https://www.google.com/search?q=" + android.net.Uri.encode(value)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() { fileChooserCallback?.onReceiveValue(null); fileChooserCallback = null; worker.shutdownNow(); if (::linux.isInitialized) linux.close(); if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
