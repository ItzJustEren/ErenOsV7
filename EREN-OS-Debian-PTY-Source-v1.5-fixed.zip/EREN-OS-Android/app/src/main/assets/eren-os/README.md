# EREN OS V7 — Freedom PWA

Responsive PWA packaging around the existing EREN OS V6 web desktop. Includes `manifest.json`, service worker shell caching, install metadata, offline app-shell fallback and app icons. Existing V6 app UI and browser-side mini-games are retained in `index.html`.

## Run locally

Service Workers require a secure context: use HTTPS hosting or localhost. Do not open `index.html` directly with `file://`.

Example if Python is installed:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser. For Android installation on a phone, deploy the folder to an HTTPS static host (for example GitHub Pages) and use the browser menu **Install app** / **Add to Home screen**. On desktop Chrome/Edge, use the install icon or browser menu.

## Offline notes

The shell and local mini-apps are cached. Google searches and other external websites require an internet connection. Browser storage may be cleared by the user/browser; this is not a native OS and its terminal operates in a browser sandbox.

## Files

- `index.html` — retained EREN OS V6 desktop with V7 PWA integration
- `manifest.json` — install metadata
- `sw.js` — app-shell cache and offline fallback
- `icons/` — PWA icons (192px, 512px, maskable)
