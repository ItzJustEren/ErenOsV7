package com.erenos.freedom

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BrowserActivity : Activity() {
    companion object { const val EXTRA_URL = "browser_url" }
    private lateinit var web: WebView
    private lateinit var address: EditText
    private val bg = Color.rgb(8, 6, 17)
    private val purple = Color.rgb(168, 85, 247)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(8, 8, 8, 0) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(38, 24, 55))); setOnClickListener { action() } }
        row.addView(button("‹") { if (web.canGoBack()) web.goBack() }, LinearLayout.LayoutParams(46, 48))
        address = EditText(this).apply { isSingleLine = true; hint = "Search Google or enter URL"; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setBackgroundColor(Color.rgb(25, 17, 37)); setPadding(12, 0, 12, 0); imeOptions = EditorInfo.IME_ACTION_GO; setOnEditorActionListener { _, actionId, _ -> if (actionId == EditorInfo.IME_ACTION_GO) { navigate(address.text.toString()); true } else false } }
        row.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        row.addView(button("Go") { navigate(address.text.toString()) }, LinearLayout.LayoutParams(58, 48))
        root.addView(row)
        val status = TextView(this).apply { text = "EREN Browser · direct web access"; textSize = 11f; setTextColor(purple); setPadding(8, 5, 8, 5) }
        root.addView(status)
        web = WebView(this).apply {
            setBackgroundColor(bg)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { address.setText(url ?: "") }
                override fun onReceivedError(view: WebView?, request: android.webkit.WebResourceRequest?, error: android.webkit.WebResourceError?) { if (request?.isForMainFrame == true) Toast.makeText(this@BrowserActivity, "Page failed to load. Check connection.", Toast.LENGTH_SHORT).show() }
            }
            webChromeClient = WebChromeClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        navigate(intent.getStringExtra(EXTRA_URL) ?: "https://www.google.com")
    }

    private fun navigate(raw: String) {
        val value = raw.trim(); if (value.isEmpty()) return
        val url = when {
            value.matches(Regex("(?i)^https?://.*")) -> value
            value.matches(Regex("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(:[0-9]+)?([/?#].*)?$")) -> "https://$value"
            else -> "https://www.google.com/search?q=" + android.net.Uri.encode(value)
        }
        address.setText(url); web.loadUrl(url)
    }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
