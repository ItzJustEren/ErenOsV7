package com.erenos.freedom

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var linux: ProotRuntime

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 6, 17)
        window.navigationBarColor = Color.rgb(8, 6, 17)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        linux = ProotRuntime(this)
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 6, 17))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.loadsImagesAutomatically = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(ErenBridge(), "ErenNative")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/eren-os/index.html")
    }

    inner class ErenBridge {
        @JavascriptInterface fun runCommand(command: String, requestId: String) {
            // Compatibility bridge for older UI builds. The live terminal uses writeTerminal().
            worker.execute {
                val result = try { linux.run(command) } catch (e: Exception) { "ERROR: ${e.message ?: e.javaClass.simpleName}" }
                runOnUiThread {
                    val js = "window.erenNativeCommandResult(${JSONObject.quote(requestId)},${JSONObject.quote(result)})"
                    web.evaluateJavascript(js, null)
                }
            }
        }
        @JavascriptInterface fun startTerminal() {
            worker.execute {
                try {
                    linux.startTerminal { chunk ->
                        runOnUiThread {
                            if (::web.isInitialized) web.evaluateJavascript("window.erenNativeTerminalOutput(${JSONObject.quote(chunk)})", null)
                        }
                    }
                } catch (e: Exception) {
                    val message = "\u001b[31mEREN Linux startup failed: ${e.message ?: e.javaClass.simpleName}\r\n\u001b[0m"
                    runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.erenNativeTerminalOutput(${JSONObject.quote(message)})", null) }
                }
            }
        }
        @JavascriptInterface fun writeTerminal(data: String) {
            worker.execute { try { linux.writeTerminal(data) } catch (e: Exception) {
                val message = "\r\n\u001b[31mPTY write error: ${e.message ?: e.javaClass.simpleName}\r\n\u001b[0m"
                runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.erenNativeTerminalOutput(${JSONObject.quote(message)})", null) }
            } }
        }
        @JavascriptInterface fun resizeTerminal(rows: Int, cols: Int) {
            worker.execute { linux.resizeTerminal(rows, cols) }
        }
        @JavascriptInterface fun openBrowser(url: String) {
            runOnUiThread {
                startActivity(Intent(this@MainActivity, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_URL, safeUrl(url)))
            }
        }
        @JavascriptInterface fun runtimeStatus(): String = linux.status()
    }

    private fun safeUrl(raw: String): String {
        val value = raw.trim()
        if (value.startsWith("https://") || value.startsWith("http://")) return value
        return "https://www.google.com/search?q=" + android.net.Uri.encode(value)
    }

    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() { worker.shutdownNow(); if (::linux.isInitialized) linux.close(); if (::web.isInitialized) web.destroy(); super.onDestroy() }
}
