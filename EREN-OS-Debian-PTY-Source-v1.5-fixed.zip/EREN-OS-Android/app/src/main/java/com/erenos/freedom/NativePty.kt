package com.erenos.freedom

/** Native PTY bridge. PRoot runs in a persistent interactive shell; fake root is not Android root. */
internal object NativePty {
    init { System.loadLibrary("erenpty") }
    external fun start(proot: String, rootfs: String, cwd: String, shared: String): IntArray?
    external fun writeFd(fd: Int, data: ByteArray): Int
    external fun readFd(fd: Int, max: Int): ByteArray?
    external fun resizeFd(fd: Int, rows: Int, cols: Int)
    external fun closeFd(fd: Int, pid: Int)
}
