# Build EREN OS Android (Debian + PTY)

You can either upload the extracted project files or keep the source ZIP in the repository.

## ZIP-first setup

1. Upload `EREN-OS-Debian-PTY-Source-v1.3.zip` to the root of your GitHub repository.
2. Copy `EREN-OS-Android/.github/workflows/android-build.yml` from the ZIP into the repository at `.github/workflows/android-build.yml` and commit it. **This workflow file must be committed separately because GitHub cannot run a workflow that exists only inside a ZIP archive.**
3. Push to `main` / `master`, or manually run **Actions → Build EREN OS Android APK → Run workflow**.
4. The workflow detects the source ZIP, extracts it, validates the Gradle project, then proceeds with SDK/NDK setup and build.
5. On success, download the `EREN-OS-Debian-PTY-arm64-debug` artifact and extract `app-debug.apk`.

If the Gradle project files already exist at the repository root, the workflow skips ZIP extraction. The APK is not prebuilt in this source ZIP. Compilation and on-device runtime testing are still separate checks.
