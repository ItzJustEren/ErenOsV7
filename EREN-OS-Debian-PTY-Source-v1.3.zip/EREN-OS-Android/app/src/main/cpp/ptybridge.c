#define _GNU_SOURCE
#include <stdio.h>
#include <fcntl.h>
#include <jni.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <poll.h>

JNIEXPORT jintArray JNICALL Java_com_erenos_freedom_NativePty_start(JNIEnv *env, jobject thiz, jstring prootJ, jstring rootfsJ, jstring cwdJ, jstring sharedJ) {
  const char *proot=(*env)->GetStringUTFChars(env,prootJ,0), *rootfs=(*env)->GetStringUTFChars(env,rootfsJ,0), *cwd=(*env)->GetStringUTFChars(env,cwdJ,0), *shared=(*env)->GetStringUTFChars(env,sharedJ,0);
  int master=-1, slave=-1; struct winsize ws={.ws_row=32,.ws_col=100,.ws_xpixel=0,.ws_ypixel=0};
  master=posix_openpt(O_RDWR|O_NOCTTY); if(master<0 || grantpt(master)<0 || unlockpt(master)<0) goto fail; char *slaveName=ptsname(master); if(!slaveName) goto fail; slave=open(slaveName,O_RDWR|O_NOCTTY); if(slave<0) goto fail; ioctl(slave,TIOCSWINSZ,&ws);
  pid_t pid=fork();
  if(pid==0){ setsid(); ioctl(slave,TIOCSCTTY,0); dup2(slave,0); dup2(slave,1); dup2(slave,2); if(slave>2)close(slave);close(master);
    unsetenv("LD_PRELOAD"); setenv("HOME","/root",1);setenv("USER","root",1);setenv("TERM","xterm-256color",1);setenv("PATH","/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",1);setenv("LANG","C.UTF-8",1);setenv("PROOT_TMP_DIR",rootfs,1); char loader[4096]; snprintf(loader,sizeof(loader),"%s",rootfs); char *slash=strrchr(loader,'/'); if(slash){ *slash=0; strncat(loader,"/libexec/proot/loader",sizeof(loader)-strlen(loader)-1); setenv("PROOT_LOADER",loader,1); }
    char bindShared[4096]; snprintf(bindShared,sizeof(bindShared),"%s:/mnt/shared",shared);
    char *argv[]={(char*)proot,"--link2symlink","-0","-r",(char*)rootfs,"-b","/dev","-b","/proc","-b","/sys","-b",bindShared,"-w",(char*)cwd,"/bin/bash","--noprofile","--norc","-i",NULL};
    execv(proot,argv); _exit(127);
  }
  close(slave); (*env)->ReleaseStringUTFChars(env,prootJ,proot);(*env)->ReleaseStringUTFChars(env,rootfsJ,rootfs);(*env)->ReleaseStringUTFChars(env,cwdJ,cwd);(*env)->ReleaseStringUTFChars(env,sharedJ,shared);
  if(pid<0){close(master);return NULL;} jint values[2]={master,(jint)pid}; jintArray result=(*env)->NewIntArray(env,2);(*env)->SetIntArrayRegion(env,result,0,2,values);return result;
fail:
  (*env)->ReleaseStringUTFChars(env,prootJ,proot);(*env)->ReleaseStringUTFChars(env,rootfsJ,rootfs);(*env)->ReleaseStringUTFChars(env,cwdJ,cwd);(*env)->ReleaseStringUTFChars(env,sharedJ,shared);return NULL;
}
JNIEXPORT jint JNICALL Java_com_erenos_freedom_NativePty_writeFd(JNIEnv*e,jobject t,jint fd,jbyteArray data){jsize n=(*e)->GetArrayLength(e,data);jbyte*b=(*e)->GetByteArrayElements(e,data,NULL);ssize_t r=write(fd,b,n);(*e)->ReleaseByteArrayElements(e,data,b,JNI_ABORT);return (jint)r;}
JNIEXPORT jbyteArray JNICALL Java_com_erenos_freedom_NativePty_readFd(JNIEnv*e,jobject t,jint fd,jint max){
  if(max<1||max>65536)max=4096;
  struct pollfd pfd; pfd.fd=fd; pfd.events=POLLIN|POLLHUP|POLLERR; pfd.revents=0;
  int ready=poll(&pfd,1,250);
  if(ready==0 || (ready<0 && errno==EINTR)) return (*e)->NewByteArray(e,0);
  if(ready<0 || (pfd.revents&(POLLHUP|POLLERR)) && !(pfd.revents&POLLIN)) return NULL;
  if(!(pfd.revents&POLLIN)) return (*e)->NewByteArray(e,0);
  jbyte*b=malloc((size_t)max); if(!b)return (*e)->NewByteArray(e,0);
  ssize_t n=read(fd,b,(size_t)max); if(n<=0){free(b);return NULL;}
  jbyteArray a=(*e)->NewByteArray(e,(jsize)n); if(n>0)(*e)->SetByteArrayRegion(e,a,0,(jsize)n,b); free(b); return a;
}
JNIEXPORT void JNICALL Java_com_erenos_freedom_NativePty_resizeFd(JNIEnv*e,jobject t,jint fd,jint rows,jint cols){struct winsize ws={.ws_row=(unsigned short)rows,.ws_col=(unsigned short)cols};ioctl(fd,TIOCSWINSZ,&ws);}
JNIEXPORT void JNICALL Java_com_erenos_freedom_NativePty_closeFd(JNIEnv*e,jobject t,jint fd,jint pid){if(fd>=0)close(fd);if(pid>0){kill(-pid,SIGHUP);kill(pid,SIGHUP);waitpid(pid,NULL,WNOHANG);}}
