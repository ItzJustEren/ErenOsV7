plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.erenos.freedom"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.erenos.freedom"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.1.0-debian-pty"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    packaging { jniLibs { useLegacyPackaging = true } }

}

dependencies {
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("org.tukaani:xz:1.10")
}
