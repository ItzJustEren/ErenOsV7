# EREN OS Android — Debian + PRoot + PTY (source revision)

This source revision upgrades the earlier Alpine command runner toward a Debian ARM64 Linux environment.

## Included in this source

- Existing EREN OS V7 desktop assets bundled locally.
- Kotlin Android shell and native in-app WebView browser.
- Debian ARM64 rootfs downloaded by GitHub Actions from the Linux Containers image server and extracted on first launch.
- PRoot launched with fake root (`-0`), `/dev`, `/proc`, `/sys` binds and a controlled app-specific shared folder bound to `/mnt/shared`.
- `LD_PRELOAD` removed from the PRoot child environment.
- Native POSIX PTY bridge (`posix_openpt` master/slave), persistent interactive Bash shell, streamed PTY output, raw input forwarding and resize signals. xterm.js plus its Fit addon are bundled locally by GitHub Actions so ANSI control sequences and interactive terminal input can be handled by a real terminal frontend.
- GitHub Actions workflow builds the native bridge, PRoot and debug APK, then uploads the APK artifact.

## Build through GitHub Actions

You can use either of these layouts:

**Option A — commit the extracted project (recommended)**
1. Upload the contents of this directory to the repository root, including `.github/workflows/android-build.yml`.
2. Open **Actions → Build EREN OS Android APK → Run workflow**.
3. Download artifact `EREN-OS-Debian-PTY-arm64-debug` from a successful run.

**Option B — keep the source ZIP in the repository**
1. Upload `EREN-OS-Debian-PTY-Source-v1.2.zip` to the repository root.
2. Also add this workflow file to the repository at `.github/workflows/android-build.yml` (GitHub cannot start a workflow that exists only inside a ZIP).
3. Run the workflow. Its first project step detects and extracts the ZIP, validates the Gradle project, and only then starts SDK/NDK setup and the APK build.
4. If the ZIP has a different filename, either rename it to match `EREN-OS-Debian-PTY-Source-v1.2.zip` / `EREN-OS-Android*.zip`, or set the `EREN_SOURCE_ZIP` environment variable in the workflow to its repository-relative path.

The extraction step is safe to re-run: if `settings.gradle.kts` and `app/build.gradle.kts` already exist at the repository root, it skips extraction.

The workflow needs network access to fetch the PRoot source, Debian rootfs, xterm.js assets, Android SDK/NDK and Gradle dependencies. It is ARM64-only and targets Android 8.0+.

## Important limitations / status

- This ZIP is **source code plus a build workflow, not a compiled APK**. No Android build or on-device execution test has been completed in this environment. A successful GitHub Actions run is required to confirm the build; installing and testing on a real ARM64 device is still required to validate the runtime.
- The native PTY and xterm.js path is implemented in source but has not yet been compiled or tested on a device. Interactive programs such as `vim` should be tested after a successful CI build; compatibility can vary with PRoot, Debian image and Android version.
- `-0` fakes Linux UID/GID 0 only inside PRoot; it does not root Android or bypass Android's app sandbox.
- `/mnt/shared` maps to the app's own external-files directory, not the entire phone storage. To access user-selected files, add Android Storage Access Framework integration; do not bind `/sdcard` blindly.
- PRoot and its loader have Android-specific execution constraints. If the workflow succeeds but PRoot cannot launch on-device, inspect the Actions logs and device logcat; a successful compile alone is not proof of runtime compatibility.
- Debian package installs use `apt`; first use `apt update`, then e.g. `apt install python3 git vim`.

## Project layout

- `app/src/main/java/...`: Kotlin activities, runtime and PTY bridge
- `app/src/main/cpp/`: JNI PTY implementation and CMake config
- `app/src/main/assets/eren-os/`: EREN OS V7 UI assets
- `.github/workflows/android-build.yml`: automated ARM64 debug APK build
